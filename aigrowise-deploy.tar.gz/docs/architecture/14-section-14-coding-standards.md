### **Section 14: Coding Standards**

Defines a minimal but mandatory set of rules for AI developers, enforcing adherence to the T3 Stack's ESLint/Prettier configuration and critical patterns for type safety and database access.

***
